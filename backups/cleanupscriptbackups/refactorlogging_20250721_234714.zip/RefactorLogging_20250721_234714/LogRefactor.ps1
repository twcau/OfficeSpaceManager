<#
.SYNOPSIS
    Finds and optionally refactors direct Write-Host, Write-Error, and Write-Warning calls to use Write-Log in the project, ensuring consistent log levels and removal of redundant icons/colors.
.DESCRIPTION
    - Backs up all files to be changed into Backups\RefactorLogging_<timestamp>\ preserving folder structure.
    - Prompts for approval before changing each file, showing before/after for each line.
    - Zips the backup folder and removes the unzipped backup after completion.
    - Provides a summary of changes and backup location.
.NOTES
    Run from the project root.
#>

param (
    [string]$ProjectRoot = (Get-Location).Path,
    [string]$BackupRoot = "Backups"
)

# --- Parse .gitignore for ignore patterns ---
$gitignorePath = Join-Path $ProjectRoot ".gitignore"
$ignorePatterns = @()
if (Test-Path $gitignorePath) {
    # Read .gitignore, skipping comments and blank lines
    $ignorePatterns = Get-Content $gitignorePath | Where-Object {
        $_ -and -not ($_ -match '^\s*#') -and -not ($_ -match '^\s*$')
    }
}

# --- Helper: Check if a path should be ignored based on .gitignore patterns ---
function Test-IsIgnored {
    param (
        [string]$Path
    )
    foreach ($pattern in $ignorePatterns) {
        # Convert gitignore pattern to wildcard for -like
        $wildcard = $pattern -replace '/', '\'
        if ($wildcard.StartsWith("*")) { $wildcard = "*$($wildcard.TrimStart("*"))" }
        if ($Path -like "*$wildcard*") { return $true }
    }
    return $false
}

# --- Helper: Map Write-Host -ForegroundColor to Write-Log -Level ---
function Get-LogLevelFromHostLine {
    param (
        [string]$line
    )
    if ($line -match '-ForegroundColor\s+Yellow') { return 'WARN' }
    if ($line -match '-ForegroundColor\s+Red') { return 'ERROR' }
    if ($line -match '-ForegroundColor\s+Green') { return 'INFO' }
    if ($line -match '-ForegroundColor\s+DarkCyan') { return 'DEBUG' }
    return 'INFO'
}

# --- Helper: Remove color switches, quotes, and leading icons/emoji from messages ---
function CleanMessage {
    param (
        [string]$msg
    )
    # Remove -ForegroundColor and trim
    $msg = $msg -replace '-ForegroundColor\s+\w+', ''
    $msg = $msg.Trim()
    # Remove leading/trailing quotes if present
    if ($msg.StartsWith('"') -and $msg.EndsWith('"')) {
        $msg = $msg.Substring(1, $msg.Length - 2)
    }
    # Remove leading icons/emoji (e.g., "⚠️", "❌", "ℹ️", "🐛") and rogue characters
    $msg = $msg -replace '^[\s`"]*[\p{So}\p{Sk}\p{Cn}\p{Zs}\p{C}]+', ''
    $msg = $msg -replace '^[^A-Za-z0-9]+', ''
    return $msg
}

# --- Helper: Remove known emoji/icons from the start of a message ---
function RemoveKnownIcons {
    param (
        [string]$msg
    )
    # List of known icons used in Write-Log
    $icons = @("⚠️", "❌", "ℹ️", "🐛")
    foreach ($icon in $icons) {
        if ($msg.TrimStart().StartsWith($icon)) {
            $msg = $msg.TrimStart().Substring($icon.Length).TrimStart()
        }
    }
    return $msg
}

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backupFolder = Join-Path $ProjectRoot "$BackupRoot\RefactorLogging_$timestamp"

# --- Find all .ps1 files not ignored by .gitignore or excluded folders ---
$filesToScan = Get-ChildItem -Path $ProjectRoot -Recurse -Include *.ps1 | Where-Object {
    $_.FullName -notmatch '\\Backups\\' -and $_.FullName -notmatch '\\Logs\\' -and -not (Test-IsIgnored $_.FullName)
}

$changeSummary = @()
$anyChanged = $false

foreach ($file in $filesToScan) {
    # Read file content
    $content = Get-Content $file.FullName
    $foundLines = @()
    for ($i = 0; $i -lt $content.Count; $i++) {
        $original = $content[$i]
        $replacement = $null

        # --- Detect Write-Host with or without color ---
        if ($original -match '^\s*Write-Host\s+') {
            $level = Get-LogLevelFromHostLine $original
            $msg = $original -replace '^\s*Write-Host\s+', ''
            $msg = CleanMessage $msg
            $msg = RemoveKnownIcons $msg
            $replacement = "Write-Log -Message `"$msg`" -Level '$level'"
        }
        # --- Detect Write-Error ---
        elseif ($original -match '^\s*Write-Error\s+') {
            $msg = $original -replace '^\s*Write-Error\s+', ''
            $msg = CleanMessage $msg
            $msg = RemoveKnownIcons $msg
            $replacement = "Write-Log -Message `"$msg`" -Level 'ERROR'"
        }
        # --- Detect Write-Warning (convert to WARN) ---
        elseif ($original -match '^\s*Write-Warning\s+') {
            $msg = $original -replace '^\s*Write-Warning\s+', ''
            $msg = CleanMessage $msg
            $msg = RemoveKnownIcons $msg
            $replacement = "Write-Log -Message `"$msg`" -Level 'WARN'"
        }

        if ($replacement) {
            $foundLines += [PSCustomObject]@{
                LineNumber  = $i + 1
                Original    = $original
                Replacement = $replacement
            }
        }
    }

    # --- If any lines found, show before/after and prompt for approval ---
    if ($foundLines.Count -gt 0) {
        Write-Host "`nFound direct output in $($file.FullName):" -ForegroundColor Yellow
        foreach ($line in $foundLines) {
            Write-Host ("  [$($line.LineNumber)] " + $line.Original) -ForegroundColor Cyan
            Write-Host ("    Will be replaced with: " + $line.Replacement) -ForegroundColor Green
        }
        $approve = Read-Host "Refactor this file to use Write-Log? (y/n)"
        if ($approve -eq 'y') {
            # --- Backup file before changes ---
            $relPath = $file.FullName.Substring($ProjectRoot.Length).TrimStart('\', '/')
            $backupPath = Join-Path $backupFolder $relPath
            $backupDir = Split-Path $backupPath
            if (-not (Test-Path $backupDir)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }
            Copy-Item $file.FullName $backupPath -Force

            # --- Refactor lines in file ---
            for ($i = 0; $i -lt $content.Count; $i++) {
                $original = $content[$i]
                $replacement = $null
                if ($original -match '^\s*Write-Host\s+') {
                    $level = Get-LogLevelFromHostLine $original
                    $msg = $original -replace '^\s*Write-Host\s+', ''
                    $msg = CleanMessage $msg
                    $msg = RemoveKnownIcons $msg
                    $content[$i] = "Write-Log -Message `"$msg`" -Level '$level'"
                }
                elseif ($original -match '^\s*Write-Error\s+') {
                    $msg = $original -replace '^\s*Write-Error\s+', ''
                    $msg = CleanMessage $msg
                    $msg = RemoveKnownIcons $msg
                    $content[$i] = "Write-Log -Message `"$msg`" -Level 'ERROR'"
                }
                elseif ($original -match '^\s*Write-Warning\s+') {
                    $msg = $original -replace '^\s*Write-Warning\s+', ''
                    $msg = CleanMessage $msg
                    $msg = RemoveKnownIcons $msg
                    $content[$i] = "Write-Log -Message `"$msg`" -Level 'WARN'"
                }
            }
            Set-Content $file.FullName $content -Encoding UTF8
            $changeSummary += $file.FullName
            $anyChanged = $true
            Write-Host "Refactored and backed up: $($file.FullName)" -ForegroundColor Green
        }
        else {
            Write-Host "Skipped: $($file.FullName)" -ForegroundColor DarkGray
        }
    }
}

# --- Zip backup folder and clean up ---
if ($anyChanged -and (Test-Path $backupFolder)) {
    $zipPath = "$backupFolder.zip"
    Write-Host "`nZipping backup folder to $zipPath..." -ForegroundColor Yellow
    Compress-Archive -Path $backupFolder -DestinationPath $zipPath -Force
    Remove-Item $backupFolder -Recurse -Force
    Write-Host "Backup zipped and original backup folder removed." -ForegroundColor Green
}

# --- Summary output ---
Write-Host "`nRefactor complete. Changed files:" -ForegroundColor White
$changeSummary | ForEach-Object { Write-Host "  $_" -ForegroundColor Cyan }
if ($anyChanged) {
    Write-Host "Backup archive: $zipPath" -ForegroundColor White
}
Write-Host "Review changes and test scripts before deploying to production." -