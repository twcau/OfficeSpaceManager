# Requires: PSScriptAnalyzer module

# Ensure PSScriptAnalyzer is available
if (-not (Get-Module -ListAvailable -Name PSScriptAnalyzer)) {
    Write-Host "PSScriptAnalyzer module is required but not installed." -ForegroundColor Yellow
    $choice = Read-Host "Would you like to install it now? (Y/N)"
    if ($choice -match '^[Yy]') {
        try {
            Install-Module -Name PSScriptAnalyzer -Scope CurrentUser -Force -ErrorAction Stop
            Write-Host "PSScriptAnalyzer installed successfully. Please re-run this script." -ForegroundColor Green
        }
        catch {
            Write-Host "Failed to install PSScriptAnalyzer: $($_.Exception.Message)" -ForegroundColor Red
        }
        exit 1
    }
    else {
        Write-Host "Please install PSScriptAnalyzer manually using:" -ForegroundColor Yellow
        Write-Host "`n    Install-Module -Name PSScriptAnalyzer -Scope CurrentUser`n" -ForegroundColor Cyan
        Write-Host "After installation, re-run this script." -ForegroundColor Yellow
        exit 1
    }
}

# Load .gitignore patterns
$gitignorePath = Join-Path (Get-Location) ".gitignore"
$ignorePatterns = @()
if (Test-Path $gitignorePath) {
    $ignorePatterns = Get-Content $gitignorePath | Where-Object { $_ -and -not $_.StartsWith('#') }
}

function Is-IgnoredFile($filePath, $ignorePatterns) {
    foreach ($pattern in $ignorePatterns) {
        $pattern = $pattern.TrimEnd('/')
        if ($pattern -eq '') { continue }
        if ($pattern -like '*/') { $pattern = $pattern.TrimEnd('/') }
        if ($filePath -like "*$pattern*") { return $true }
    }
    return $false
}

# Gather all .ps1 files, respecting .gitignore
$ps1Files = Get-ChildItem -Path . -Filter *.ps1 -Recurse | Where-Object {
    -not (Is-IgnoredFile $_.FullName $ignorePatterns)
}

# For cross-script duplicate function detection
$allFunctions = @{}

# First pass: collect all function names for duplicate detection
foreach ($file in $ps1Files) {
    $lines = Get-Content $file.FullName
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match '^\s*function\s+([a-zA-Z0-9\-_]+)') {
            $fname = $matches[1]
            if (-not $allFunctions.ContainsKey($fname)) {
                $allFunctions[$fname] = @()
            }
            $allFunctions[$fname] += $file.FullName
        }
    }
}

# Prepare results array
$results = @()

foreach ($file in $ps1Files) {
    $lines = Get-Content $file.FullName
    $hasParam = $false
    $paramLine = 0
    $hasErrorHandler = $false
    $errorHandlerLine = 0
    $hasWriteLog = $false
    $hasHeaderComment = $false
    $hasInputValidation = $false
    $hasVerbose = $false
    $hasWhatIf = $false
    $hasRequiredFunctions = $false
    $externalDependencies = @()
    $unusedImports = @()
    $functionsDefined = @()
    $functionsCalled = @()
    $parametersDefined = @()
    $parametersUsed = @()
    $riskyCommands = @()
    $hardcodedSecrets = @()
    $writeHostLines = @()
    $missingSynopsis = $true
    $missingDescription = $true
    $missingParamValidation = @()
    $longFunctions = @()
    $deepNesting = $false
    $inFunction = $false
    $functionStart = 0
    $functionName = ""
    $functionLines = 0
    $maxNesting = 0
    $currentNesting = 0
    $functionHelpBlocks = @()
    $missingFunctionHelp = @()
    $missingParamHelp = @()
    $hasTestFile = $false
    $slowCmdletsInLoops = @()
    $suggestions = @()

    # Check for header comment
    if ($lines.Count -gt 0 -and $lines[0] -match '^\s*<#') { $hasHeaderComment = $true }

    # Check for .SYNOPSIS and .DESCRIPTION in header
    foreach ($l in $lines[0..([Math]::Min($lines.Count - 1, 20))]) {
        if ($l -match '\.SYNOPSIS') { $missingSynopsis = $false }
        if ($l -match '\.DESCRIPTION') { $missingDescription = $false }
    }

    # Dependency Analysis & Security Checks
    for ($i = 0; $i -lt $lines.Count; $i++) {
        $line = $lines[$i]
        # Module imports
        if ($line -match '^\s*Import-Module\s+([^\s#]+)') {
            $externalDependencies += $matches[1]
            if (-not ($lines | Select-String -Pattern $matches[1] -Quiet)) { $unusedImports += $matches[1] }
        }
        # Dot-sourcing (robust: match . "path" or . 'path' or . path)
        if ($line -match '^\s*\.\s*["'']?([^\s"''`]+\.ps1)["'']?') {
            $externalDependencies += $matches[1]
        }
        # Risky commands
        if ($line -match 'Invoke-Expression|Add-Type|ConvertTo-SecureString\s+-AsPlainText') {
            $riskyCommands += "Line $($i+1): $line"
        }
        # Hardcoded secrets (commented out due to regex issues)
        # if ($line -match '-Password|-Credential|[Pp]assword\s*=' -or $line -match '[\'"][A-Za-z0-9!@#$%^&*()\-_=+]{8,}[\'"]') {
        #    $hardcodedSecrets += "Line $($i+1): $line"
        #}
        # Write-Host
        if ($line -match 'Write-Host') {
            $writeHostLines += "Line $($i+1): $line"
        }
        # Parameter validation
        if ($line -match '^\s*\[Parameter\(') {
            if ($line -notmatch 'ValidateSet|ValidatePattern|ValidateNotNullOrEmpty') {
                $missingParamValidation += "Line $($i+1): $line"
            }
        }
        # Input validation
        if ($line -match 'Read-Host|ValidateSet|ValidatePattern|if\s*\(.*-match.*\)') {
            $hasInputValidation = $true
        }
        # Verbose/Debug
        if ($line -match 'Write-Verbose|Write-Debug') {
            $hasVerbose = $true
        }
        # WhatIf/DryRun
        if ($line -match '-WhatIf|-DryRun') {
            $hasWhatIf = $true
        }
        # Write-Log
        if ($line -match 'Write-Log') {
            $hasWriteLog = $true
        }
        # Error handler
        if ($line -match 'Global-ErrorHandling\.ps1' -and !$hasErrorHandler) {
            $hasErrorHandler = $true
            $errorHandlerLine = $i + 1
        }
        # Param block
        if ($line -match '^\s*param\s*\(' -and !$hasParam) {
            $hasParam = $true
            $paramLine = $i + 1
        }
        # Function definition
        if ($line -match '^\s*function\s+([a-zA-Z0-9\-_]+)') {
            $inFunction = $true
            $functionStart = $i
            $functionName = $matches[1]
            $functionsDefined += $functionName
            $functionLines = 0
            $maxNesting = 0
            $currentNesting = 0
            # Check for help block
            if ($i -eq 0 -or $lines[$i - 1] -notmatch '<#') {
                $missingFunctionHelp += $functionName
            }
        }
        if ($inFunction) {
            $functionLines++
            $currentNesting += ($line -split '{').Count - 1
            $currentNesting -= ($line -split '}').Count - 1
            if ($currentNesting > $maxNesting) { $maxNesting = $currentNesting }
            if ($currentNesting -le 0 -and $line -match '^\s*\}') {
                $inFunction = $false
                if ($functionLines -gt 100) { $longFunctions += "$functionName ($functionLines lines)" }
                if ($maxNesting -gt 3) { $deepNesting = $true }
            }
        }
        if ($line -match '([a-zA-Z0-9\-_]+)\s*\(') {
            $functionsCalled += $matches[1]
        }
        if ($line -match 'param\s*\((.*)\)') {
            $params = $matches[1] -split ','
            foreach ($p in $params) {
                $p = $p.Trim()
                if ($p -match '\$([a-zA-Z0-9_]+)') {
                    $parametersDefined += $matches[1]
                }
            }
        }
        if ($line -match '\$([a-zA-Z0-9_]+)') {
            $parametersUsed += $matches[1]
        }
        if ($line -match 'foreach|for|while') {
            $loopLine = $i
            for ($j = $i + 1; $j -lt [Math]::Min($i + 10, $lines.Count); $j++) {
                if ($lines[$j] -match 'Get-Content|Start-Sleep|Select-String') {
                    $slowCmdletsInLoops += "Line $($j+1): $($lines[$j])"
                }
            }
        }
    }

    $unusedFunctions = @()
    foreach ($f in $functionsDefined) {
        if ($functionsCalled -notcontains $f) { $unusedFunctions += $f }
    }
    $unusedParameters = @()
    foreach ($p in $parametersDefined) {
        if ($parametersUsed -notcontains $p) { $unusedParameters += $p }
    }

    $duplicateFunctions = @()
    foreach ($f in $functionsDefined) {
        if ($allFunctions[$f].Count -gt 1) { $duplicateFunctions += "$f (also in $($allFunctions[$f] -join ', '))" }
    }

    $testFile = $file.FullName -replace '\.ps1$', '.Tests.ps1'
    if (Test-Path $testFile) { $hasTestFile = $true }

    if (-not $hasHeaderComment) { $suggestions += "Add or improve header comment." }
    if ($missingSynopsis) { $suggestions += "Add .SYNOPSIS to header comment." }
    if ($missingDescription) { $suggestions += "Add .DESCRIPTION to header comment." }
    if ($hasParam -and $hasErrorHandler -and $errorHandlerLine -lt $paramLine) { $suggestions += "Move param block above error handler." }
    if (-not $hasErrorHandler) { $suggestions += "Dot-source Global-ErrorHandling.ps1 after param block." }
    if (-not $hasWriteLog) { $suggestions += "Add Write-Log calls for key actions." }
    if (-not $hasInputValidation) { $suggestions += "Add input validation for user/script input." }
    if (-not $hasVerbose) { $suggestions += "Add Write-Verbose or Write-Debug for detailed output." }
    if (-not $hasWhatIf) { $suggestions += "Consider supporting -WhatIf or -DryRun for safe testing." }
    if ($externalDependencies.Count) { $suggestions += "External dependencies: $($externalDependencies -join ', ')" }
    if ($unusedImports.Count) { $suggestions += "Unused module imports: $($unusedImports -join ', ')" }
    if ($riskyCommands.Count) { $suggestions += "Risky commands: $($riskyCommands -join '; ')" }
    if ($hardcodedSecrets.Count) { $suggestions += "Possible hardcoded secrets: $($hardcodedSecrets -join '; ')" }
    if ($writeHostLines.Count) { $suggestions += "Use Write-Output/Write-Verbose instead of Write-Host: $($writeHostLines -join '; ')" }
    if ($missingParamValidation.Count) { $suggestions += "Add parameter validation attributes: $($missingParamValidation -join '; ')" }
    if ($longFunctions.Count) { $suggestions += "Long functions (consider refactoring): $($longFunctions -join ', ')" }
    if ($deepNesting) { $suggestions += "Deeply nested code blocks detected (consider refactoring)." }
    if ($duplicateFunctions.Count) { $suggestions += "Duplicate function names: $($duplicateFunctions -join ', ')" }
    if ($missingFunctionHelp.Count) { $suggestions += "Functions missing help comments: $($missingFunctionHelp -join ', ')" }
    if ($unusedFunctions.Count) { $suggestions += "Unused functions: $($unusedFunctions -join ', ')" }
    if ($unusedParameters.Count) { $suggestions += "Unused parameters: $($unusedParameters -join ', ')" }
    if (-not $hasTestFile) { $suggestions += "No corresponding .Tests.ps1 file found." }
    if ($slowCmdletsInLoops.Count) { $suggestions += "Slow cmdlets in loops: $($slowCmdletsInLoops -join '; ')" }

    $psaIssues = @()
    try {
        $psaIssues = Invoke-ScriptAnalyzer -Path $file.FullName -Recurse -Severity Warning, Error -ErrorAction SilentlyContinue
    }
    catch {}
    foreach ($issue in $psaIssues) {
        $suggestions += "PSScriptAnalyzer: [$($issue.RuleName)] $($issue.Message) (Line $($issue.Line))"
    }

    $vscodeLink = "vscode://file/$($file.FullName.Replace('\','/'))"

    $results += [PSCustomObject]@{
        File                   = $file.FullName
        VSCodeLink             = $vscodeLink
        ParamLine              = if ($hasParam) { $paramLine } else { "" }
        ErrorHandlerLine       = if ($hasErrorHandler) { $errorHandlerLine } else { "" }
        HasHeaderComment       = $hasHeaderComment
        HasParamBlock          = $hasParam
        HasErrorHandler        = $hasErrorHandler
        HasWriteLog            = $hasWriteLog
        HasInputValidation     = $hasInputValidation
        HasVerbose             = $hasVerbose
        HasWhatIf              = $hasWhatIf
        ExternalDependencies   = $externalDependencies -join ', '
        UnusedImports          = $unusedImports -join ', '
        RiskyCommands          = $riskyCommands -join '; '
        HardcodedSecrets       = $hardcodedSecrets -join '; '
        WriteHostLines         = $writeHostLines -join '; '
        MissingParamValidation = $missingParamValidation -join '; '
        LongFunctions          = $longFunctions -join ', '
        DeepNesting            = $deepNesting
        DuplicateFunctions     = $duplicateFunctions -join ', '
        MissingFunctionHelp    = $missingFunctionHelp -join ', '
        UnusedFunctions        = $unusedFunctions -join ', '
        UnusedParameters       = $unusedParameters -join ', '
        HasTestFile            = $hasTestFile
        SlowCmdletsInLoops     = $slowCmdletsInLoops -join '; '
        Suggestions            = if ($suggestions) { $suggestions -join "`n" } else { "No issues found." }
    }
}

# Helper: Format multi-line fields for Markdown
function Format-MultiLineField {
    param($value)
    if ([string]::IsNullOrWhiteSpace($value)) { return "" }
    # Insert <br /> after each semicolon if followed by " Line" or digit (for Write-Host/Sleep)
    return ($value -replace ';(\s*Line\s*\d+:)', ';<br />$1')
}

# Helper: Format suggestions as Markdown bullet list
function Format-Suggestions {
    param($suggestions)
    if ([string]::IsNullOrWhiteSpace($suggestions)) { return "" }
    # Split on newlines or ". " or "; " for better readability
    $split = $suggestions -split "(\.`n|; |\. )"
    $bullets = $split | Where-Object { $_.Trim() -ne "" } | ForEach-Object { "* $($_.Trim())" }
    return $bullets -join "`n"
}

# Output CSV
$results | Export-Csv -NoTypeInformation -Path .\script_review_report.csv

# Output Markdown
$md = @("# PowerShell Script Review Report", "")
foreach ($r in $results) {
    $md += "## [$($r.File)]($($r.VSCodeLink))"
    $md += ""

    # Only add non-empty property rows
    $props = @{
        "Param Line"            = $r.ParamLine
        "Error Handler Line"    = $r.ErrorHandlerLine
        "Header Comment"        = $r.HasHeaderComment
        "Param Block"           = $r.HasParamBlock
        "Error Handler"         = $r.HasErrorHandler
        "Write-Log"             = $r.HasWriteLog
        "Input Validation"      = $r.HasInputValidation
        "Verbose/Debug"         = $r.HasVerbose
        "WhatIf/DryRun"         = $r.HasWhatIf
        "External Dependencies" = $r.ExternalDependencies
        "Unused Imports"        = $r.UnusedImports
        "Risky Commands"        = $r.RiskyCommands
        "Write-Host Usage"      = Format-MultiLineField $r.WriteHostLines
        "Param Validation"      = $r.MissingParamValidation
        "Long Functions"        = $r.LongFunctions
        "Deep Nesting"          = if ($r.DeepNesting) { "Yes" } else { "" }
        "Duplicate Functions"   = $r.DuplicateFunctions
        "Missing Function Help" = $r.MissingFunctionHelp
        "Unused Functions"      = $r.UnusedFunctions
        "Unused Parameters"     = $r.UnusedParameters
        "Has Test File"         = if ($r.HasTestFile) { "Yes" } else { "" }
        "Slow Cmdlets in Loops" = Format-MultiLineField $r.SlowCmdletsInLoops
    }

    $md += "| Property | Value |"
    $md += "|----------|-------|"
    foreach ($k in $props.Keys) {
        if ($props[$k] -and $props[$k].ToString().Trim() -ne "") {
            $md += "| $k | $($props[$k]) |"
        }
    }
    $md += ""
    $md += "**Suggestions/Issues:**"
    $md += ""
    $md += Format-Suggestions $r.Suggestions
    $md += ""
}

Set-Content -Path .\script_review_report.md -Value $md -Encoding UTF8

# Colorized console summary
# ...existing code...

Write-Host "`n==== Script Review Summary ====" -ForegroundColor Cyan
foreach ($r in $results) {
    $fileName = Split-Path $r.File -Leaf
    $issueCount = ($r.Suggestions -split "`n").Count
    $suggestionsLower = $r.Suggestions.ToLower()
    $color = "Green"
    if ($suggestionsLower -match "error|fail|risky|missing|unused|duplicate|long|deep|no corresponding|add|move|dot-source|write-host|parameter validation|slow") {
        $color = "Yellow"
    }
    if ($suggestionsLower -match "error|fail|risky") {
        $color = "Red"
    }
    Write-Host "${fileName}: $issueCount suggestion(s)" -ForegroundColor $color
    if ($color -ne "Green") {
        Write-Host "  See details in script_review_report.md" -ForegroundColor $color
    }
}
Write-Host "`nScript review complete. See script_review_report.md and script_review_report.csv for details." -ForegroundColor Cyan