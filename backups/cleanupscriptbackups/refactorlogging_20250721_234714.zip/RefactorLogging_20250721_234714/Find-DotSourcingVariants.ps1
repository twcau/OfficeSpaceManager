. "$PSScriptRoot/../Shared/Global-ErrorHandling.ps1"
<#
.SYNOPSIS
    Finds all dot-sourcing variants in .ps1 files in the workspace.
.DESCRIPTION
    Scans each line of each .ps1 file (excluding Backups and Logs) for all common dot-sourcing patterns.
    Prints a table of matches: file, line number, matched text, and regex variant.
#>

$root = Get-Location
$files = Get-ChildItem -Path $root -Filter *.ps1 -Recurse -File |
Where-Object { $_.FullName -notmatch '\\Backups\\' -and $_.FullName -notmatch '\\Logs\\' }

# Define regexes for each variant (all use double quotes for PowerShell compatibility)
$regexVariants = @(
    @{ Name = 'Quoted $PSScriptRoot'; Pattern = [regex]"\.\s*['""]\$PSScriptRoot[\\/][^'""]+\.ps1['""]" },
    @{ Name = 'Unquoted $PSScriptRoot'; Pattern = [regex]"\.\s*\$PSScriptRoot[\\/][^\s]+\.ps1" },
    @{ Name = 'Quoted Absolute'; Pattern = [regex]"\.\s*['""][A-Z]:\\[^'""]+\.ps1['""]" },
    @{ Name = 'Unquoted Absolute'; Pattern = [regex]"\.\s*[A-Z]:\\[^\s]+\.ps1" }
)

$results = @()

foreach ($file in $files) {
    $lines = Get-Content $file.FullName
    for ($i = 0; $i -lt $lines.Count; $i++) {
        $line = $lines[$i]
        foreach ($variant in $regexVariants) {
            $regex = $variant.Pattern
            if ($regex.IsMatch($line)) {
                $results += [PSCustomObject]@{
                    File    = $file.FullName.Substring($root.Path.Length + 1)
                    LineNum = $i + 1
                    Variant = $variant.Name
                    Match   = $line.Trim()
                }
            }
        }
    }
}

if ($results.Count -eq 0) {
    Write-Host "No dot-sourcing patterns found." -ForegroundColor Yellow
}
else {
    $results | Sort-Object File, LineNum | Format-Table -AutoSize
    Write-Host "`nTotal matches: $($results.Count)" -ForegroundColor Green
}
