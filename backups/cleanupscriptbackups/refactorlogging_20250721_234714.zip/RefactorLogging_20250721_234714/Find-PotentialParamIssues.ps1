# Load .gitignore patterns
$gitignorePath = Join-Path (Get-Location) ".gitignore"
$ignorePatterns = @()
if (Test-Path $gitignorePath) {
    $ignorePatterns = Get-Content $gitignorePath | Where-Object { $_ -and -not $_.StartsWith('#') }
}

function Is-IgnoredFile($filePath, $ignorePatterns) {
    foreach ($pattern in $ignorePatterns) {
        $pattern = $pattern.TrimEnd('/')
        if ($pattern -eq '') { continue }
        if ($pattern -like '*/') { $pattern = $pattern.TrimEnd('/') }
        if ($filePath -like "*$pattern*") { return $true }
    }
    return $false
}

Get-ChildItem -Path . -Filter *.ps1 -Recurse | Where-Object {
    -not (Is-IgnoredFile $_.FullName $ignorePatterns)
} | ForEach-Object {
    $lines = Get-Content $_.FullName
    $inFunction = $false
    for ($i = 0; $i -lt $lines.Count; $i++) {
        $line = $lines[$i].Trim()
        # Track function blocks
        if ($line -match '^function\b') { $inFunction = $true }
        if ($inFunction -and $line -match '^\}') { $inFunction = $false; continue }
        # Only check param blocks outside functions
        if (-not $inFunction -and $line -match '^param\s*\(') {
            # Check for non-comment, non-blank, non-header lines before param
            $beforeParam = @()
            for ($j = 0; $j -lt $i; $j++) {
                $l = $lines[$j]
                if ($l -notmatch '^\s*#' -and $l -notmatch '^\s*<' -and $l -notmatch '^\s*>' -and $l -notmatch '^\s*$') {
                    $beforeParam += [PSCustomObject]@{
                        LineNumber = $j + 1
                        Content    = $l
                    }
                }
            }
            if ($beforeParam.Count -gt 0) {
                Write-Host "Potential issue in $($_.FullName):"
                Write-Host "  'param' block is not the first executable statement (see lines before param):"
                foreach ($item in $beforeParam) {
                    Write-Host ("    Line {0}: {1}" -f $item.LineNumber, $item.Content)
                }
                Write-Host ""
            }
        }
    }
}