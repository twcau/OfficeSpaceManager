# Fix-ParamPlacement.ps1
$timestamp = Get-Date -Format "yyyyMMdd_HHmm"
$backupDir = ".\Backups\ParamFix_$timestamp"
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

Write-Host "🔍 Scanning for PS1 files and fixing misplaced param blocks..." -ForegroundColor Cyan

Get-ChildItem -Recurse -Filter *.ps1 | ForEach-Object {
    $file = $_.FullName
    $lines = Get-Content $file

    # Skip files with no param block
    $paramIndex = $lines.FindIndex({ $_ -match '^\s*param\s*\(' })
    if ($paramIndex -eq -1) { return }

    # Skip if param is already at top (within first 10 lines)
    if ($paramIndex -le 10 -and ($lines[0] -match '^<#' -or $lines[0] -match '^\s*param\s*\(')) { return }

    # Backup original file
    $relativePath = Resolve-Path -Relative $file
    $destBackup = Join-Path $backupDir (Split-Path $relativePath -Leaf)
    Copy-Item -Path $file -Destination $destBackup -Force

    # Identify comment block if any
    $startComment = $lines.FindIndex({ $_ -match '^<#' })
    $endComment   = $lines.FindIndex({ $_ -match '#>' })
    $hasHeader    = ($startComment -ne -1 -and $endComment -gt $startComment)

    # Extract and remove param block
    $paramBlock = $lines[$paramIndex]
    $lines.RemoveAt($paramIndex)

    # Insert param block in right position
    if ($hasHeader) {
        $insertAt = $endComment + 1
    } else {
        $insertAt = 0
    }

    $lines.Insert($insertAt, $paramBlock)

    # Save changes
    Set-Content -Path $file -Value $lines -Force
    Write-Host "✔️ Fixed: $($relativePath)" -ForegroundColor Green
}

Write-Host "`n✅ All applicable files updated. Backup saved to: $backupDir" -ForegroundColor Cyan
