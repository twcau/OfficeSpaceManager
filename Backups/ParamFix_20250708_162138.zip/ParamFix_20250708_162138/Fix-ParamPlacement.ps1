﻿# Fix-ParamPlacement.ps1
# ✅ Improved version that handles multiple quirks, param location, deduplication, and structure

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backupDir = ".\Backups\ParamFix_$timestamp"
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

Write-Host "🔍 Scanning for .ps1 files and fixing misplaced or duplicate param() blocks..." -ForegroundColor Cyan

# Find index helper
function Find-Index {
    param (
        [array]$array,
        [scriptblock]$predicate
    )
    for ($i = 0; $i -lt $array.Count; $i++) {
        if (& $predicate $array[$i]) {
            return $i
        }
    }
    return -1
}

# Recursively get all PS1 files (ignore logs + backups)
$files = Get-ChildItem -Recurse -Filter *.ps1 | Where-Object {
    $_.FullName -notmatch '\\Logs\\' -and $_.FullName -notmatch '\\Backups\\'
}

foreach ($file in $files) {
    $filePath = $file.FullName
    $lines = Get-Content $filePath -Raw -Encoding UTF8 -ErrorAction Stop -Force
    $lineList = $lines -split "`n" | ForEach-Object { $_.TrimEnd() }
    $originalLines = $lineList.Clone()

    # Find all param() blocks
    $paramLines = $lineList | Select-String -Pattern '^\s*param\s*\('
    if ($paramLines.Count -eq 0) { continue }

    # Warn if >1 param() block found
    if ($paramLines.Count -gt 1) {
        Write-Warning "⚠️ Multiple param() blocks in $($file.Name). Keeping only the first one."
    }

    $firstParamIndex = $paramLines[0].LineNumber - 1
    $paramLine = $lineList[$firstParamIndex]

    # Remove all param() blocks (start of line param() only)
    $lineList = $lineList | Where-Object { $_ -notmatch '^\s*param\s*\(' }

    # Detect comment header
    $headerStart = Find-Index $lineList { $_ -match '^\s*<#' }
    $headerEnd   = Find-Index $lineList { $_ -match '#>\s*$' }
    $hasHeader = ($headerStart -ge 0 -and $headerEnd -gt $headerStart)

    $insertIndex = if ($hasHeader) { $headerEnd + 1 } else { 0 }
    $lineList.Insert($insertIndex, "")
    $lineList.Insert($insertIndex, $paramLine)

    # Final touch: backup + write
    $backupPath = Join-Path $backupDir $file.Name
    Copy-Item $filePath $backupPath -Force
    Set-Content -Path $filePath -Value $lineList -Encoding UTF8

    Write-Host "✔️ Fixed param() in: $($file.FullName.Replace($PWD.Path, '.'))" -ForegroundColor Green
}

Write-Host "`n✅ All applicable scripts fixed. Backups saved to: $backupDir" -ForegroundColor Cyan
